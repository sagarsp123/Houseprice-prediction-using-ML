module.exports = {

	database: 'mongodb://localhost/db'
}
